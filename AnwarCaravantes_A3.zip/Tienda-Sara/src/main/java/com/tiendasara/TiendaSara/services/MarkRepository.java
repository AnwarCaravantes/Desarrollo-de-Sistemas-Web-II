package com.tiendasara.TiendaSara.services;

import org.springframework.data.jpa.repository.JpaRepository;
import com.tiendasara.TiendaSara.models.Mark;

public interface MarkRepository extends JpaRepository<Mark, Integer>{
}