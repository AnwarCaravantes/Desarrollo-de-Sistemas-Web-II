package com.tiendasara.TiendaSara.services;

import org.springframework.data.jpa.repository.JpaRepository;
import com.tiendasara.TiendaSara.models.Category;

public interface CategoryRepository extends JpaRepository<Category, Integer>{
}



