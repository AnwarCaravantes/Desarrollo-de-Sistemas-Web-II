package com.tiendasara.TiendaSara.models;

import jakarta.validation.constraints.*;

public class ProductDto {

    @Size(min = 10, message = "The description should be at least 10 characters")
    @Size(max = 2000, message = "The description cannot exceed 2000 characters")
    private String description;

    @Min(value = 0, message = "El precio debe ser mayor o igual a 0")
    private double price;

    @Min(value = 0, message = "La cantidad debe ser mayor o igual a 0")
    private int amount;

    @NotNull(message = "La categoría es requerida")
    private Integer categoryId;

    @NotNull(message = "La marca es requerida")
    private Integer markId;
    
    private String imageFileName;

    // Getters y Setters
    public String getDescription() { 
        return description; 
    }
    public void setDescription(String description) { 
        this.description = description; 
    }

    public double getPrice() { 
        return price; 
    }
    public void setPrice(double price) { 
        this.price = price; 
    }

    public int getAmount() { 
        return amount; 
    }
    public void setAmount(int amount) { 
        this.amount = amount; 
    }

    public Integer getCategoryId() { 
        return categoryId; 
    }
    public void setCategoryId(Integer categoryId) { 
        this.categoryId = categoryId; 
    }

    public Integer getMarkId() { 
        return markId; 
    }
    public void setMarkId(Integer markId) { 
        this.markId = markId; 
    }

    public String getImageFileName() { 
        return imageFileName; 
    }
    public void setImageFileName(String imageFileName) { 
        this.imageFileName = imageFileName; 
    }
}