package com.tiendasara.TiendaSara.services;

import com.tiendasara.TiendaSara.models.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

public interface ProductRepository extends JpaRepository<Product, Integer> {

    @Modifying
    @Transactional
    @Query(value = "DELETE FROM CarritoDetalle WHERE IdProducto = :productId", nativeQuery = true)
    void deleteCarritoDetalleByProductId(@Param("productId") int productId);
}