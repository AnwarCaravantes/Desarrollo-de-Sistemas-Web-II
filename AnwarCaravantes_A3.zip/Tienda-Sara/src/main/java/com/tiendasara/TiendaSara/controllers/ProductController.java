package com.tiendasara.TiendaSara.controllers;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.tiendasara.TiendaSara.models.Category;
import com.tiendasara.TiendaSara.models.Mark;
import com.tiendasara.TiendaSara.models.Product;
import com.tiendasara.TiendaSara.models.ProductDto;
import com.tiendasara.TiendaSara.services.CategoryRepository;
import com.tiendasara.TiendaSara.services.MarkRepository;
import com.tiendasara.TiendaSara.services.ProductRepository;

import jakarta.validation.Valid;

@Controller
@RequestMapping("/products")
public class ProductController {

    @Autowired
    private ProductRepository repo;

    @Autowired
    private CategoryRepository repo2;

    @Autowired
    private MarkRepository repo3;

    @GetMapping({"", "/"})
    public String showProductList(Model model) {
        List<Product> products = repo.findAll();
        model.addAttribute("products", products);
        return "products/index";
    }

    public List<Category> getListCategories() {
        return repo2.findAll(); 
    }

    public List<Mark> getListMarks() {
        return repo3.findAll(); 
    }

   @GetMapping("/create")
public String showCreatePage(Model model) {
    ProductDto productDto = new ProductDto();
    model.addAttribute("productDto", productDto);
    
    // listas para los menús desplegables
    model.addAttribute("categories", repo2.findAll());
    model.addAttribute("marks", repo3.findAll());
    
    return "products/CreateProduct";
}

    @PostMapping("/create")
public String createProduct(
        @Valid @ModelAttribute ProductDto productDto,
        BindingResult result,
        Model model
) {
    if (result.hasErrors()) {
        model.addAttribute("categories", repo2.findAll());
        model.addAttribute("marks", repo3.findAll());
        return "products/CreateProduct";
    }


    Category category = repo2.findById(productDto.getCategoryId()).orElse(null);
    Mark mark = repo3.findById(productDto.getMarkId()).orElse(null);

    Product product = new Product();
    product.setDescription(productDto.getDescription());
    product.setPrice(productDto.getPrice());
    product.setAmount(productDto.getAmount());
    product.setImageFileName(productDto.getImageFileName());
    product.setCategory(category);
    product.setMark(mark);

    repo.save(product);

    return "redirect:/products";
}

    @GetMapping("/edit")
    public String showEditPage(
            Model model,
            @RequestParam int id
    ) {
        try {
            Product product = repo.findById(id).get();
            model.addAttribute("product", product);
            model.addAttribute("categories", getListCategories());
            model.addAttribute("marks", getListMarks());

            ProductDto productDto = new ProductDto();
            productDto.setDescription(product.getDescription());
            productDto.setPrice(product.getPrice());
            productDto.setAmount(product.getAmount());
            if (product.getCategory() != null) {
                productDto.setCategoryId(product.getCategory().getId());
            }
            if (product.getMark() != null) {
                productDto.setMarkId(product.getMark().getId());
}
            productDto.setImageFileName(product.getImageFileName());

            model.addAttribute("productDto", productDto);

        } catch (Exception ex) {
            System.out.println("Exception: " + ex.getMessage());
            return "redirect:/products";
        }

        return "products/EditProduct";
    }

    @PostMapping("/edit")
public String updateProduct(
        Model model,
        @RequestParam int id,
        @Valid @ModelAttribute ProductDto productDto,
        BindingResult result
) {
    Product product = repo.findById(id).orElse(null);
    if (product == null) {
        return "redirect:/products";
    }

    if (result.hasErrors()) {
        model.addAttribute("product", product);
        model.addAttribute("categories", repo2.findAll());
        model.addAttribute("marks", repo3.findAll());
        return "products/EditProduct";
    }

   
    Category category = repo2.findById(productDto.getCategoryId()).orElse(null);
    Mark mark = repo3.findById(productDto.getMarkId()).orElse(null);

    product.setDescription(productDto.getDescription());
    product.setPrice(productDto.getPrice());
    product.setAmount(productDto.getAmount());
    product.setImageFileName(productDto.getImageFileName());
    product.setCategory(category);
    product.setMark(mark);

    repo.save(product);

    return "redirect:/products";
}

   @GetMapping("/delete")
public String deleteProduct(@RequestParam int id) {
    try {
        Product product = repo.findById(id).orElse(null);
        if (product != null) {
            repo.deleteCarritoDetalleByProductId(id);
            repo.delete(product);
        }
    } catch (Exception ex) {
        System.out.println("Error al eliminar el producto: " + ex.getMessage());
    }
    
    return "redirect:/products";
}
}
