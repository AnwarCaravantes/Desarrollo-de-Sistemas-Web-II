package com.tiendasara.TiendaSara;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TiendaSaraApplicationTests {

	@Test
	void contextLoads() {
	}

}
